# Project iOS Dual Boot (prototype)

Android app prototype for browsing IPSW.me firmware metadata and downloading user-selected Apple IPSW files.

## Important limitations

- The app does not boot iOS.
- The Boot button is intentionally disabled.
- IPSWs are device-specific; an iPhone IPSW is not Moto G60 firmware.
- No partitioning, flashing, root commands, or bootloader changes are performed.
- Firmware size/hash metadata may be absent; this prototype does not claim cryptographic signature verification.

## Build

Use JDK 17 and Gradle 8.9 with Android SDK 35:
`gradle assembleDebug`

The GitHub Actions workflow builds a debug APK in the cloud.
