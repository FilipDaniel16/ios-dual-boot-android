package com.filipdaniel.iosdualboot

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.DecimalFormat
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var status: TextView
    private lateinit var deviceSpinner: Spinner
    private lateinit var firmwareSpinner: Spinner
    private lateinit var loadButton: Button
    private lateinit var downloadButton: Button
    private lateinit var bootButton: Button
    private var devices: List<Device> = emptyList()
    private var firmwares: List<Firmware> = emptyList()

    data class Device(val name: String, val identifier: String) {
        override fun toString() = "$name ($identifier)"
    }
    data class Firmware(
        val version: String,
        val build: String,
        val url: String,
        val size: Long,
        val signed: Boolean
    ) {
        override fun toString(): String {
            val gb = DecimalFormat("0.00").format(size / 1_000_000_000.0)
            return "$version ($build) • ${gb} GB • " + if (signed) "Signed" else "Unsigned"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        loadDevices()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
            setBackgroundColor(0xFFF5F6FA.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = "Project iOS Dual Boot"
            textSize = 25f
            setTextColor(0xFF171923.toInt())
            gravity = Gravity.CENTER_VERTICAL
        }
        content.addView(title, matchWrap())
        content.addView(TextView(this).apply {
            text = "Firmware browser • IPSW downloader • compatibility research"
            textSize = 14f
            setTextColor(0xFF4B5563.toInt())
            setPadding(0, dp(6), 0, dp(18))
        }, matchWrap())

        content.addView(label("Apple firmware device"))
        deviceSpinner = Spinner(this)
        content.addView(deviceSpinner, matchWrap())

        loadButton = Button(this).apply {
            text = "Load firmware versions"
            setOnClickListener { loadFirmwares() }
        }
        content.addView(loadButton, matchWrap())

        content.addView(label("Available IPSW firmware"))
        firmwareSpinner = Spinner(this)
        content.addView(firmwareSpinner, matchWrap())

        downloadButton = Button(this).apply {
            text = "Download selected IPSW"
            setOnClickListener { downloadSelectedFirmware() }
        }
        content.addView(downloadButton, matchWrap())

        bootButton = Button(this).apply {
            text = "Boot iOS (not available)"
            isEnabled = false
        }
        content.addView(bootButton, matchWrap())

        content.addView(TextView(this).apply {
            text = "Compatibility notice"
            textSize = 18f
            setTextColor(0xFF171923.toInt())
            setPadding(0, dp(18), 0, dp(6))
        }, matchWrap())
        content.addView(TextView(this).apply {
            text = "This app runs on Android 12 on a Motorola Moto G60. Downloading an IPSW does not make it compatible with this phone. Genuine iOS boot has NOT been implemented or verified. The Boot button stays disabled; this app will not repartition storage or modify bootloader/system partitions."
            textSize = 14f
            setTextColor(0xFF7F1D1D.toInt())
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(0xFFFFE4E6.toInt())
        }, matchWrap())

        status = TextView(this).apply {
            text = "Connecting to IPSW.me…"
            textSize = 14f
            setTextColor(0xFF374151.toInt())
            setPadding(0, dp(16), 0, dp(8))
        }
        content.addView(status, matchWrap())

        content.addView(Button(this).apply {
            text = "Open IPSW.me"
            setOnClickListener {
                startActivity(android.content.Intent(
                    android.content.Intent.ACTION_VIEW,
                    Uri.parse("https://ipsw.me/")
                ))
            }
        }, matchWrap())

        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        setContentView(root)
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 16f
        setTextColor(0xFF111827.toInt())
        setPadding(0, dp(12), 0, dp(4))
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun getJson(urlText: String): String {
        val connection = URL(urlText).openConnection() as HttpURLConnection
        connection.connectTimeout = 15000
        connection.readTimeout = 20000
        connection.setRequestProperty("User-Agent", "ProjectIosDualBoot/0.1")
        return try {
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val text = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) error("HTTP $code")
            text
        } finally {
            connection.disconnect()
        }
    }

    private fun loadDevices() {
        status.text = "Loading Apple device list from IPSW.me…"
        loadButton.isEnabled = false
        executor.execute {
            try {
                val json = JSONArray(getJson("https://api.ipsw.me/v4/devices"))
                val list = mutableListOf<Device>()
                for (i in 0 until json.length()) {
                    val obj = json.getJSONObject(i)
                    val name = obj.optString("name", "")
                    val id = obj.optString("identifier", "")
                    if (name.isNotBlank() && id.isNotBlank()) list.add(Device(name, id))
                }
                list.sortBy { it.name.lowercase() }
                runOnUiThread {
                    devices = list
                    deviceSpinner.adapter = ArrayAdapter(
                        this, android.R.layout.simple_spinner_dropdown_item, devices
                    )
                    status.text = "Loaded ${devices.size} Apple device models. Select a model, then load its firmware."
                    loadButton.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Could not load device list: ${e.message}. Check your connection and try again."
                    loadButton.isEnabled = true
                }
            }
        }
    }

    private fun loadFirmwares() {
        if (devices.isEmpty() || deviceSpinner.selectedItemPosition < 0) {
            status.text = "Device list is not ready yet."
            return
        }
        val device = devices[deviceSpinner.selectedItemPosition]
        loadButton.isEnabled = false
        status.text = "Loading firmware for ${device.name}…"
        executor.execute {
            try {
                val obj = JSONObject(getJson("https://api.ipsw.me/v4/device/${device.identifier}?type=ipsw"))
                val array = obj.optJSONArray("firmwares") ?: JSONArray()
                val list = mutableListOf<Firmware>()
                for (i in 0 until array.length()) {
                    val f = array.getJSONObject(i)
                    val url = f.optString("url", "")
                    if (url.startsWith("https://") && f.optString("version").isNotBlank()) {
                        list.add(Firmware(
                            version = f.optString("version", "Unknown"),
                            build = f.optString("buildid", "Unknown"),
                            url = url,
                            size = f.optLong("filesize", 0L),
                            signed = f.optBoolean("signed", false)
                        ))
                    }
                }
                list.sortWith(compareByDescending<Firmware> { it.version })
                runOnUiThread {
                    firmwares = list
                    firmwareSpinner.adapter = ArrayAdapter(
                        this, android.R.layout.simple_spinner_dropdown_item, firmwares
                    )
                    status.text = "Found ${firmwares.size} IPSW entries for ${device.name}. These are Apple-device firmware files, not Moto G60 firmware."
                    loadButton.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Could not load firmware list: ${e.message}"
                    loadButton.isEnabled = true
                }
            }
        }
    }

    private fun downloadSelectedFirmware() {
        if (firmwares.isEmpty() || firmwareSpinner.selectedItemPosition < 0) {
            status.text = "Load a firmware list and select an IPSW first."
            return
        }
        val firmware = firmwares[firmwareSpinner.selectedItemPosition]
        val gb = DecimalFormat("0.00").format(firmware.size / 1_000_000_000.0)
        android.app.AlertDialog.Builder(this)
            .setTitle("Download ${firmware.version}?")
            .setMessage("This will download an Apple firmware file (about $gb GB when size metadata is available). It will not install iOS or make it compatible with the Moto G60. Ensure you have enough storage and Wi-Fi.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Download") { _, _ ->
                try {
                    val request = DownloadManager.Request(Uri.parse(firmware.url))
                        .setTitle("iOS ${firmware.version} IPSW")
                        .setDescription("Apple firmware download; not installable on the Moto G60")
                        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                        .setAllowedOverMetered(false)
                        .setAllowedOverRoaming(false)
                        .setDestinationInExternalPublicDir(
                            Environment.DIRECTORY_DOWNLOADS,
                            "iOS-${firmware.version}-${firmware.build}.ipsw"
                        )
                    val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                    manager.enqueue(request)
                    status.text = "Download queued. Track progress in Android notifications or Downloads. No system partitions were changed."
                } catch (e: Exception) {
                    status.text = "Could not start download: ${e.message}"
                }
            }.show()
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
    }
}
