plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.filipdaniel.iosdualboot"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.filipdaniel.iosdualboot"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}
